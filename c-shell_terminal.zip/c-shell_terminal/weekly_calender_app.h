void createList(int, char []);
void displayMyList();
