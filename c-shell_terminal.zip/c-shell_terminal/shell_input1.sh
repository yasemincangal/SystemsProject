((area=5*5))
echo $area
