for counter in {1..10}
do
echo -n "output of program input shell 2: $counter "
done
printf "\n"
